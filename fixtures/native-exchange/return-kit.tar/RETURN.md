# BVE return kit V1 (additive companion)

This kit includes the exact frozen manifest and ordered original sources. Give the receiving session this entire kit, the deliberately supplied originals, and explicit operator instructions. It has no presumed BVE connection. Nothing here starts generation. The operator must report/claim the exact run/slot in BVE BEFORE authorizing one invocation and relay approval or denial. Stop on denied, stale, withdrawn, expired or uncertain authority. Never retry a claim, invoke twice, call an unconfigured service or substitute another provider. A download is not a new allowance.

Use only manifest.json's prompt/request/sources. Sources remain exact originals. Return the actual output file; never have a language model transcribe base64 or metadata. Never convert, resize or re-encode to pass dimensions. Unknown real model/seed/usage/cost/provider/host invocation values stay null. BVE IDs are not host invocation IDs. Synthetic fixtures must keep every real provenance field null and must not claim native generation. Imported origin and operator-attestation-only are mandatory; digest echo proves neither authentication nor generation.

## Deterministic local construction

Tooling: Node 24.19.x, sharp 0.35.5 and ajv 8.20.0 (standard BVE locked dependencies). Use an existing offline tooling environment with these packages available to build-return.mjs. No provider installation or image call. In an isolated kit directory copy returned-template-v1.json or failed-template-v1.json to filled.json. Fill receiptId, rights, attestation.statement and message with nonempty truthful strings. The returned template is intentionally incomplete until an original is supplied.

Run: node build-return.mjs filled.json return-directory /absolute/path/to/original.png
Failed: node build-return.mjs filled.json return-directory

The builder fully decodes PNG/JPEG/WebP with sharp (single frame; 8 MiB,16 MP,8192 edge), checks exact requested width/height and no source substitution, computes SHA-256 from original bytes with node:crypto and byte length from the buffer, records encoded dimensions/format and copies unchanged original bytes. MIME maps png=image/png,jpeg=image/jpeg,webp=image/webp; the wire descriptor stores format, not MIME. id and checksum both equal SHA-256; assets/<hash>.jpg for jpeg, otherwise the format extension. The schema defines every result field; BVE independently repeats parsing, full decoding and ownership checks. Descriptor id/checksum/path and bytes/dimensions must agree; usage JSON is at most12000 canonical characters, result at most256 KiB.

Choose a stable receiptId (1–160 letters/digits/_/-) for this one return. Reuse it ONLY for byte-identical manifest replay. A changed payload under the same job/receiptId conflicts. A new receipt does not authorize a new invocation. Upload result.json and its named original through this exact run/slot's Import form. Failed results have output:null and no file. Late/withdrawn/uncertain evidence needs the explicit historical checkbox and creates no current membership. Selection, Library and acceptance stay separate.

Binding/digest/evidence are fixed in both templates and result-schema-v1.json for job afb3dedb7ab71d1d72063599a4a996563a8110c5523d2f14c07cad2cf3924225, slot 1. kit.json records these exact bindings. This companion never rewrites frozen V1 releases, old receipts or request re-download bytes. Schema/build success is offline evidence only; actual host compatibility remains unverified.
